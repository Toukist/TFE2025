import { Component } from '@angular/core';
@Component({
  selector: 'app-performance',
  standalone: true,
  template: `<h2>Métriques de l'équipe</h2><p>Contenu test Manager - Performance</p>`
})
export class PerformanceComponent {}

// Supprimé : fusion et déplacement dans manager/
// Voir manager/ pour la version à jour.
