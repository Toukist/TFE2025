import { Component } from '@angular/core';
@Component({
  selector: 'app-equipe',
  standalone: true,
  template: `<h2>Supervision des membres</h2><p>Contenu test Manager - Equipe</p>`
})
export class EquipeComponent {}

// Supprimé : fusion et déplacement dans manager/
// Voir manager/ pour la version à jour.
