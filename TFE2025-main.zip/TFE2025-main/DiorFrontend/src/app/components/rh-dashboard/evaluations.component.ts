import { Component } from '@angular/core';
@Component({
  selector: 'app-evaluations',
  standalone: true,
  template: `<h2>Gestion des évaluations</h2><p>Contenu test RH - Evaluations</p>`
})
export class EvaluationsComponent {}
