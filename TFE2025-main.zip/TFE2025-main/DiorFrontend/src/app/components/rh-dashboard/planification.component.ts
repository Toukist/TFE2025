import { Component } from '@angular/core';
@Component({
  selector: 'app-planification',
  standalone: true,
  template: `<h2>Organisation des horaires</h2><p>Contenu test RH - Planification</p>`
})
export class PlanificationComponent {}
