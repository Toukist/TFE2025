import { Component } from '@angular/core';
@Component({
  selector: 'app-personnel',
  standalone: true,
  template: `<h2>Suivi des employés</h2><p>Contenu test RH - Personnel</p>`
})
export class PersonnelComponent {}
