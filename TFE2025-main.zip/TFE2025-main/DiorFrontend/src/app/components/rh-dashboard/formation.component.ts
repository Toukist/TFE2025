import { Component } from '@angular/core';
@Component({
  selector: 'app-formation',
  standalone: true,
  template: `<h2>Suivi des formations</h2><p>Contenu test RH - Formation</p>`
})
export class FormationComponent {}
