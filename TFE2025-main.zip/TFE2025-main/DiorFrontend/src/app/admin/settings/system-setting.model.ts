export interface SystemSetting {
  id: number;
  key: string;
  value: string;
  updatedAt: string;
  updatedBy: string;
}
