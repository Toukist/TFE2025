﻿using Dior.Library.Interfaces.UserInterface.Services;
using Dior.Library.Service.DAO;
using Dior.Library.Entities;

namespace Dior.Service.Services.UserInterfaces
{
    public class PrivilegeService : IPrivilegeService
    {
        private readonly IDA_Privilege _daPrivilege;

        public PrivilegeService(IDA_Privilege daPrivilege)
        {
            _daPrivilege = daPrivilege;
        }

        public Privilege Get(long id)
        {
            // Correction : Mapper explicitement l'objet BO vers Entities
            var boPrivilege = _daPrivilege.Get((int)id);
            return MapToEntityPrivilege(boPrivilege);
        }

        public List<Privilege> GetList()
        {
            // Correction : Mapper explicitement la liste d'objets BO vers Entities
            var boList = _daPrivilege.GetList();
            return boList.Select(MapToEntityPrivilege).ToList();
        }

        public long Add(Privilege privilege, string editBy)
        {
            return _daPrivilege.Add(privilege, editBy);
        }

        public void Set(Privilege privilege, string editBy)
        {
            _daPrivilege.Set(privilege, editBy);
        }

        public void Del(long id)
        {
            _daPrivilege.Del((int)id);
        }

        // Méthode de mapping explicite
        private Privilege MapToEntityPrivilege(Dior.Library.BO.UserInterface.Privilege boPrivilege)
        {
            if (boPrivilege == null) return null;
            return new Privilege
            {
                Id = boPrivilege.Id,
                Name = boPrivilege.Name,
                // Ajoutez ici les autres propriétés nécessaires
            };
        }
    }
}
