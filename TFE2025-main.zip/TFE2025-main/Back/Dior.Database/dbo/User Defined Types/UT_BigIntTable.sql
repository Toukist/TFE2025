﻿CREATE TYPE [dbo].[UT_BigIntTable] AS TABLE (
    [Value] BIGINT NULL);

