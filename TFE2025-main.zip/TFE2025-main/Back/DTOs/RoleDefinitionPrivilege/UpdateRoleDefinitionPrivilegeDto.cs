namespace Dior.Database.DTOs.RoleDefinitionPrivilege
{
    public class UpdateRoleDefinitionPrivilegeDto
    {
        public string LastEditBy { get; set; }
    }
}