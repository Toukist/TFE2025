namespace Dior.Database.DTOs.UserAccessCompetency
{
    public class UpdateUserAccessCompetencyDto
    {
        public string LastEditBy { get; set; }
    }
}