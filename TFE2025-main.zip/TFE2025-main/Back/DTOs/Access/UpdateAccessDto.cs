namespace Dior.Database.DTOs.Access
{
    public class UpdateAccessDto
    {
        public string BadgePhysicalNumber { get; set; }
        public bool IsActive { get; set; }
    }
}