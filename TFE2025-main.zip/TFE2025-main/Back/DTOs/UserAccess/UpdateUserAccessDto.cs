namespace Dior.Database.DTOs.UserAccess
{
    public class UpdateUserAccessDto
    {
        public string LastEditBy { get; set; }
    }
}