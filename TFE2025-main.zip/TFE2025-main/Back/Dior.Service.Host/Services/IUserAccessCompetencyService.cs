namespace Dior.Service.Host.Services
{
    // Cette interface locale n'est pas n�cessaire et doit �tre supprim�e pour �viter toute confusion
}