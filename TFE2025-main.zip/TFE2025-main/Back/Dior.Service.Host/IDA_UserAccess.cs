﻿internal class IDA_UserAccess
{
}